package com.HolyLight.decor.blocks;

public interface IDecor
{
    String getModelPath();

    String getTexturePath();
}
