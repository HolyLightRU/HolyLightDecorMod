package com.HolyLight.decor;

import cpw.mods.fml.common.event.*;

public class CommonProxy
{
    public void preInit(final FMLPreInitializationEvent event) {
    }

    public void init(final FMLInitializationEvent event) {
    }

    public void postInit(final FMLPostInitializationEvent event) {
    }
}
