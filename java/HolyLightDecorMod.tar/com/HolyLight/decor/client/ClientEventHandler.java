package com.HolyLight.decor.client;

import static com.HolyLight.decor.Main.IS_SERVER;

import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.client.Minecraft;

public class ClientEventHandler  {



}
